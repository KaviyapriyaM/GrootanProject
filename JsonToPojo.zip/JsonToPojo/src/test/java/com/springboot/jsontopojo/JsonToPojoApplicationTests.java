package com.springboot.jsontopojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonToPojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
