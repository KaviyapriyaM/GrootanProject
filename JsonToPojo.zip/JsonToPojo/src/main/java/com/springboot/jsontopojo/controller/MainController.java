package com.springboot.jsontopojo.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.codemodel.JCodeModel;

import org.jsonschema2pojo.DefaultGenerationConfig;  
import org.jsonschema2pojo.GenerationConfig;  
import org.jsonschema2pojo.Jackson2Annotator;  
import org.jsonschema2pojo.SchemaGenerator;  
import org.jsonschema2pojo.SchemaMapper;  
import org.jsonschema2pojo.SchemaStore;  
import org.jsonschema2pojo.SourceType;  
import org.jsonschema2pojo.rules.RuleFactory; 

@Controller
public class MainController {

	@RequestMapping("/")
	public String first() {
		return "index.html";
	}
	
	@RequestMapping("/getPojo")
	public String getPojo(@RequestParam(value = "json") File inputJson) {
		String packageName="com.springboot.output";
		File in = new File("." + File.separator + "inputJson");
		File outputPojoDirectory = new File("." + File.separator + "convertedPojo");
		outputPojoDirectory.mkdirs();
		try {
			
			new MainController().convert2JSON(in.toURI().toURL(), outputPojoDirectory, packageName,
					in.getName());
		} catch (IOException e) {
			System.out.println("Encountered issue while converting to pojo: " + e.getMessage());
			e.printStackTrace();
		}
		return "display.html";
	}

	public void convert2JSON(URL inputJson, File outputPojoDirectory, String packageName, String className)
			throws IOException {
		JCodeModel codeModel = new JCodeModel();
		URL source = inputJson;
		GenerationConfig config = new DefaultGenerationConfig() {
			@Override
			public boolean isGenerateBuilders() { // set config option by overriding method
				return true;
			}

			public SourceType getSourceType() {
				return SourceType.JSON;
			}
		};
		SchemaMapper mapper = new SchemaMapper(
				new RuleFactory(config, new Jackson2Annotator(config), new SchemaStore()), new SchemaGenerator());
		mapper.generate(codeModel, className, packageName, source);
		codeModel.build(outputPojoDirectory);
	}

}
